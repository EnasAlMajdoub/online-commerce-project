<?php
include 'includes/header.php';
include '../Middleware/adminMiddleware.php';
?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4>Welcome To Admin Dashboard</h4>
        </div>
        <div class="card-body">
          <?php
           include 'includes/footer.php';
             ?>
        </div>
      </div>
			
              
		</div>
	</div>
</div>

